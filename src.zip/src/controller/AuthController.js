import React, { createContext, useState, useContext } from 'react';

const AuthContext = createContext({});

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  const login = async (email, password) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Validação de Cliente (App padrão)
        if (email === 'lucas@gmail.com' && password === '123456') {
          const clientUser = { id: 1, name: 'Lucas', role: 'CLIENT', email };
          setUser(clientUser);
          resolve(clientUser);
        } 
        // Validação de Atendente / Caixa (atendimentoView)
        else if (email === 'joao@gmail.com' && password === '123456') {
          const attendantUser = { id: 2, name: 'João', role: 'ATTENDANT', email };
          setUser(attendantUser);
          resolve(attendantUser);
        } 
        // Validação de Cozinha (cozinhaView)
        else if (email === 'augusto@gmail.com' && password === '123456') {
          const kitchenUser = { id: 3, name: 'Augusto', role: 'KITCHEN', email };
          setUser(kitchenUser);
          resolve(kitchenUser);
        } else if (email === 'admin@gmail.com' && password === '123456') {
          const adminUser = { id: 3, name: 'ADMIN', role: 'ADMIN', email };
          setUser(adminUser);
          resolve(adminUser);
        }  
        // Falha
        else {
          reject(new Error('Credenciais inválidas. Tente usar as contas de demonstração.'));
        }
      }, 800); // Simulando tempo de requisição
    });
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
