/**
 * src/controller/CatalogController.js
 *
 * Mesma ideia do AuthController: concentra os dados e as regras do cardápio,
 * das mesas, da equipe e das configurações do restaurante num lugar só.
 * As telas não guardam mais listas fixas — elas consomem `useCatalog()`.
 *
 * Para plugar a API: troque as funções `load*` por chamadas HTTP.
 */
import React, { createContext, useContext, useMemo, useState } from 'react';
import { PRODUCTS, CATEGORIES, TABLES, STAFF, RESTAURANT } from '../data/demoData';

const CatalogContext = createContext(null);

const clone = (list) => list.map(item => ({ ...item }));

const loadProducts = () => clone(PRODUCTS);
const loadCategories = () => clone(CATEGORIES);
const loadTables = () => clone(TABLES);
const loadStaff = () => clone(STAFF);
const loadSettings = () => ({ ...RESTAURANT });

export const TABLE_STATUS = ['Livre', 'Ocupada', 'Aguardando pagamento', 'Reservada'];
export const STAFF_ROLES = ['Administrador', 'Gerente', 'Garçom', 'Cozinheiro', 'Caixa'];

/* ==========================================
   MONTAGEM DE REGISTROS A PARTIR DO FORMULÁRIO
========================================== */
export const buildProduct = (form, id) => ({
  id: id || String(Date.now()),
  name: form.name.trim(),
  description: form.description.trim() || 'Produto do cardápio',
  category: form.category,
  price: form.price,
  active: true,
  highlight: false,
});

export const buildCategory = (form, id) => ({
  id: id || `c${Date.now()}`,
  name: form.name.trim(),
  description: form.description.trim() || 'Nova categoria do cardápio',
  active: true,
});

export const buildTable = (form, id) => ({
  id: id || String(Date.now()),
  number: form.number.trim(),
  status: 'Livre',
  waiter: null,
});

export const buildStaff = (form, id) => ({
  id: id || String(Date.now()),
  name: form.name.trim(),
  role: form.role,
  cpf: form.cpf || 'Não informado',
  phone: form.phone || 'Não informado',
  login: form.name.trim().toLowerCase().replace(/\s+/g, '.'),
  active: true,
});

/* ==========================================
   PROVIDER
========================================== */
export const CatalogProvider = ({ children }) => {
  const [products, setProducts] = useState(loadProducts);
  const [rawCategories, setCategories] = useState(loadCategories);
  const [tables, setTables] = useState(loadTables);
  const [staff, setStaff] = useState(loadStaff);
  const [settings, setSettings] = useState(loadSettings);

  // A contagem de itens por categoria é calculada, não digitada.
  const categories = useMemo(
    () =>
      rawCategories.map(category => ({
        ...category,
        count: products.filter(product => product.category === category.name).length,
      })),
    [rawCategories, products],
  );

  const activeProducts = useMemo(() => products.filter(product => product.active), [products]);
  const activeStaff = useMemo(() => staff.filter(person => person.active), [staff]);

  const value = {
    products,
    activeProducts,
    setProducts,
    categories,
    setCategories,
    tables,
    setTables,
    staff,
    activeStaff,
    setStaff,
    settings,
    setSettings,
    updateSetting: (key, newValue) => setSettings(current => ({ ...current, [key]: newValue })),
  };

  return <CatalogContext.Provider value={value}>{children}</CatalogContext.Provider>;
};

export const useCatalog = () => {
  const context = useContext(CatalogContext);
  if (!context) {
    throw new Error('useCatalog precisa estar dentro de <CatalogProvider>.');
  }
  return context;
};
