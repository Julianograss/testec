/**
 * src/services/api.js
 *
 * Camada única de acesso à API. Todo o app fala com o back-end através
 * daqui — nenhum controller usa `fetch` diretamente.
 *
 * MODO MOCK: enquanto o back-end do Fogo & Fumaça não existe, USE_MOCK_API
 * mantém o app funcional simulando a rede (latência incluída) e devolvendo
 * o próprio payload enviado, como um servidor "echo". Estrutura, tratamento
 * de erro e chamadas continuam sendo as reais — no dia em que a API subir,
 * basta:
 *   1. Ajustar API_BASE_URL para o endereço do back-end.
 *   2. Trocar USE_MOCK_API para false.
 * Nenhum outro arquivo do app precisa mudar.
 */

export const API_BASE_URL = 'https://api.fogoefumaca.com.br'; // TODO: apontar para o back-end real
export const USE_MOCK_API = true; // TODO: false quando o back-end estiver no ar

const MOCK_LATENCY_MS = 400;
const wait = (ms = MOCK_LATENCY_MS) => new Promise(resolve => setTimeout(resolve, ms));

export class ApiError extends Error {
  status: number;
  constructor(message: string, status = 0) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

/**
 * Requisição HTTP genérica. Em modo mock, "resolve" a chamada localmente
 * (sem rede) devolvendo o corpo enviado — quem persiste de fato, nesse
 * modo, é o estado local do controller que chamou a API.
 */
async function request(method: string, path: string, body?: unknown) {
  if (USE_MOCK_API) {
    await wait();
    // Simula uma falha ocasional de rede seria possível aqui; mantemos
    // sempre sucesso para não atrapalhar a demonstração.
    return body ?? { ok: true };
  }

  let response: Response;
  try {
    response = await fetch(`${API_BASE_URL}${path}`, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch (networkError: any) {
    throw new ApiError(networkError?.message || 'Falha de conexão com o servidor.', 0);
  }

  if (!response.ok) {
    const text = await response.text().catch(() => '');
    throw new ApiError(text || `Erro ${response.status} ao acessar ${path}.`, response.status);
  }

  if (response.status === 204) return null;
  return response.json().catch(() => null);
}

export const apiGet = (path: string) => request('GET', path);
export const apiPost = (path: string, body?: unknown) => request('POST', path, body);
export const apiPut = (path: string, body?: unknown) => request('PUT', path, body);
export const apiPatch = (path: string, body?: unknown) => request('PATCH', path, body);
export const apiDelete = (path: string) => request('DELETE', path);

/* ==========================================
   RECURSOS
========================================== */
export const productsApi = {
  list: () => apiGet('/products'),
  create: (product: any) => apiPost('/products', product),
  update: (id: string, patch: any) => apiPut(`/products/${id}`, patch),
  remove: (id: string) => apiDelete(`/products/${id}`),
};

export const categoriesApi = {
  list: () => apiGet('/categories'),
  create: (category: any) => apiPost('/categories', category),
  update: (id: string, patch: any) => apiPut(`/categories/${id}`, patch),
  remove: (id: string) => apiDelete(`/categories/${id}`),
};

export const tablesApi = {
  list: () => apiGet('/tables'),
  create: (table: any) => apiPost('/tables', table),
  update: (id: string, patch: any) => apiPut(`/tables/${id}`, patch),
  remove: (id: string) => apiDelete(`/tables/${id}`),
};

export const staffApi = {
  list: () => apiGet('/staff'),
  create: (member: any) => apiPost('/staff', member),
  update: (id: string, patch: any) => apiPut(`/staff/${id}`, patch),
  remove: (id: string) => apiDelete(`/staff/${id}`),
};

export const settingsApi = {
  get: () => apiGet('/settings'),
  update: (settings: any) => apiPut('/settings', settings),
};

export const ordersApi = {
  list: () => apiGet('/orders'),
  create: (order: any) => apiPost('/orders', order),
  updateStatus: (id: string, status: string, extra?: any) =>
    apiPatch(`/orders/${id}/status`, { status, ...extra }),
  updateNotes: (id: string, notes: string) => apiPatch(`/orders/${id}/notes`, { notes }),
};

export const authApi = {
  login: (email: string, password: string) => apiPost('/auth/login', { email, password }),
  changePassword: (payload: { currentPassword: string; newPassword: string }) =>
    apiPost('/account/change-password', payload),
  endOtherSessions: () => apiPost('/account/end-other-sessions'),
};

export const reportsApi = {
  /** Pede ao back-end o PDF já pronto (base64 ou URL, a depender da API). */
  exportPdf: (payload: { period: string; html: string }) => apiPost('/reports/export-pdf', payload),
};