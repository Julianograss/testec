import React, { createContext, useContext, useState, type ReactNode } from 'react';
interface TableSessionValue { tableNumber: string | null; sessionActive: boolean; openTableSession: (number: string) => void; closeTableSession: () => void; }
const TableSessionContext = createContext<TableSessionValue | undefined>(undefined);
export function TableSessionProvider({ children }: { children: ReactNode }) {
  const [tableNumber, setTableNumber] = useState<string | null>(null);
  const [sessionActive, setSessionActive] = useState(false);
  const openTableSession = (number: string) => { setTableNumber(number); setSessionActive(true); };
  const closeTableSession = () => { setTableNumber(null); setSessionActive(false); };
  return <TableSessionContext.Provider value={{ tableNumber, sessionActive, openTableSession, closeTableSession }}>{children}</TableSessionContext.Provider>;
}
export function useTableSession(): TableSessionValue { const context = useContext(TableSessionContext); if (!context) throw new Error('useTableSession precisa estar dentro de <TableSessionProvider>.'); return context; }
