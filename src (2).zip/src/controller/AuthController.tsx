import React, { createContext, useContext, useState, type ReactNode } from 'react';

export type UserRole = 'CLIENT' | 'ATTENDANT' | 'KITCHEN' | 'ADMIN';
export interface AuthUser { id: number; name: string; role: UserRole; email: string; }
interface AuthContextValue { user: AuthUser | null; login: (email: string, password: string) => Promise<AuthUser>; logout: () => void; }
const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const login = async (email: string, password: string): Promise<AuthUser> => new Promise((resolve, reject) => {
    setTimeout(() => {
      const accounts: Record<string, AuthUser> = {
        'lucas@gmail.com': { id: 1, name: 'Lucas', role: 'CLIENT', email },
        'joao@gmail.com': { id: 2, name: 'João', role: 'ATTENDANT', email },
        'augusto@gmail.com': { id: 3, name: 'Augusto', role: 'KITCHEN', email },
        'admin@gmail.com': { id: 4, name: 'Admin', role: 'ADMIN', email },
      };
      const loggedUser = password === '123456' ? accounts[email] : undefined;
      if (!loggedUser) { reject(new Error('Credenciais inválidas. Tente usar as contas de demonstração.')); return; }
      setUser(loggedUser); resolve(loggedUser);
    }, 400);
  });
  const logout = () => setUser(null);
  return <AuthContext.Provider value={{ user, login, logout }}>{children}</AuthContext.Provider>;
}
export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth precisa estar dentro de <AuthProvider>.');
  return context;
}
